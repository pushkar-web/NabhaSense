'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import dynamic from 'next/dynamic';
import Sidebar from '@/components/layout/Sidebar';
import Topbar from '@/components/layout/Topbar';
import DashboardPanel from '@/components/dashboard/DashboardPanel';
import ScenarioSimulator from '@/components/dashboard/ScenarioSimulator';
import CityComparison from '@/components/dashboard/CityComparison';

const HeatMap = dynamic(() => import('@/components/map/HeatMap'), { ssr: false });

const cities = ['Mumbai', 'Thane', 'Delhi', 'Bangalore', 'Chennai', 'Hyderabad', 'Pune'];

const getRiskColor = (risk: string) => ({
  low: '#00d4aa', medium: '#ffd700', high: '#ff6b35', extreme: '#ff3d3d',
  Low: '#00d4aa', Medium: '#ffd700', High: '#ff6b35', Extreme: '#ff3d3d',
}[risk] || '#fff');

export default function Home() {
  const [selectedCity, setSelectedCity] = useState('Thane');
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [hotspots, setHotspots] = useState<any[]>([]);
  const [interventions, setInterventions] = useState<any[]>([]);

  // activeSection drives both the sidebar highlight AND which tab content shows below the map
  const [activeSection, setActiveSection] = useState('dashboard');
  const [activeTab, setActiveTab] = useState<'hotspots' | 'interventions' | 'predict' | 'simulate' | 'compare'>('hotspots');

  const [predictInput, setPredictInput] = useState({ lst: 38, ndvi: 0.3, ndbi: 0.5, humidity: 60, buildingDensity: 65 });
  const [predictResult, setPredictResult] = useState<any>(null);

  const analyzeCity = async (city: string) => {
    setLoading(true);
    setSelectedCity(city);
    setAnalysis(null);
    setActiveSection('dashboard');
    try {
      const [a, h, i] = await Promise.all([
        fetch(`https://nabhasense-backend.onrender.com/heat/analysis/${city.toLowerCase()}`).then(r => r.json()),
        fetch(`https://nabhasense-backend.onrender.com/heat/hotspots/${city.toLowerCase()}`).then(r => r.json()),
        fetch(`https://nabhasense-backend.onrender.com/heat/interventions/${city.toLowerCase()}`).then(r => r.json()),
      ]);
      setAnalysis(a);
      setHotspots(h.hotspots || []);
      setInterventions(i.interventions || []);
    } catch (e) { console.error(e); }
    setLoading(false);
  };

  const handlePredict = async () => {
    try {
      const res = await fetch('https://nabhasense-backend.onrender.com/heat/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(predictInput),
      });
      setPredictResult(await res.json());
    } catch (e) { console.error(e); }
  };

  const interventionIcons: any = {
    urban_greening: '🌳', cool_roof: '🏠', water_body: '💧', ventilation: '💨',
  };

  // Map sidebar section keys → tab keys
  const handleNavigate = (section: string) => {
    setActiveSection(section);
    const sectionToTab: any = {
      hotspots: 'hotspots',
      cooling: 'interventions',
      predictions: 'predict',
      simulate: 'simulate',
      compare: 'compare',
    };
    if (sectionToTab[section]) setActiveTab(sectionToTab[section]);
  };

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#0a0f1e', overflow: 'hidden', fontFamily: 'Inter, system-ui, sans-serif' }}>

      {/* ── SIDEBAR ── */}
      <Sidebar activeSection={activeSection} onNavigate={handleNavigate} />

      {/* ── MAIN CONTENT ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* ── TOPBAR ── */}
        <Topbar dateRange={analysis?.lstPeriod ?? '2026-05-17 to 2026-06-16'} />

        {/* ── SCROLLABLE CONTENT ── */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: '12px' }}>

          {/* ── HERO SECTION (always visible) ── */}
          <div style={{
            background: 'linear-gradient(135deg, #0a0f1e 0%, #0d1e38 50%, #091220 100%)',
            border: '1px solid #1e2d4a',
            borderRadius: '12px',
            padding: '18px 20px',
            position: 'relative',
            overflow: 'hidden',
          }}>
            {/* Space glow */}
            <div style={{
              position: 'absolute', right: 0, top: 0, bottom: 0, width: '40%',
              background: 'radial-gradient(ellipse at 80% 50%, rgba(0,100,200,0.12) 0%, transparent 70%)',
              pointerEvents: 'none',
            }} />

            <motion.div initial={{ opacity: 0, y: -16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
              <h1 style={{ fontSize: 'clamp(20px, 3vw, 32px)', fontWeight: 900, lineHeight: 1.15, marginBottom: '6px' }}>
                <span style={{ color: '#f0f4ff' }}>Urban Heat </span>
                <span style={{ background: 'linear-gradient(135deg, #00d4aa, #0099ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>Intelligence</span>
                <span style={{ color: '#f0f4ff' }}> Platform</span>
              </h1>
              <p style={{ color: '#8892b0', fontSize: '11px', marginBottom: '14px' }}>
                Physics-informed AI/ML system for urban heat stress detection and cooling intervention optimization
              </p>

              {/* City pills */}
              <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '14px' }}>
                {cities.map(city => (
                  <motion.button key={city} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.96 }}
                    onClick={() => analyzeCity(city)}
                    style={{
                      padding: '5px 14px', borderRadius: '20px', cursor: 'pointer', fontSize: '11px', fontWeight: 500,
                      border: selectedCity === city ? '1.5px solid #00d4aa' : '1.5px solid #1e2d4a',
                      background: selectedCity === city ? 'rgba(0,212,170,0.12)' : 'rgba(255,255,255,0.03)',
                      color: selectedCity === city ? '#00d4aa' : '#8892b0',
                    }}>{city}</motion.button>
                ))}
              </div>

              {/* Analyze button */}
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                onClick={() => analyzeCity(selectedCity)}
                style={{
                  padding: '9px 24px', borderRadius: '24px', border: 'none',
                  background: loading ? '#1e2d4a' : 'linear-gradient(135deg, #00d4aa, #0099ff)',
                  color: loading ? '#8892b0' : '#fff',
                  fontSize: '13px', fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer',
                  display: 'inline-flex', alignItems: 'center', gap: '6px',
                }}>
                🛰️ {loading ? 'Fetching real satellite data...' : 'Analyze Heat Data'}
              </motion.button>

              {/* Status badges */}
              {analysis && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '12px' }}>
                  <span style={{ background: 'rgba(0,212,170,0.12)', border: '1px solid #00d4aa40', borderRadius: '20px', padding: '3px 12px', fontSize: '10px', color: '#00d4aa', fontWeight: 600 }}>
                    ✅ Live Data — {analysis.dataSource}
                  </span>
                  <span style={{ background: 'rgba(0,153,255,0.12)', border: '1px solid #0099ff40', borderRadius: '20px', padding: '3px 12px', fontSize: '10px', color: '#0099ff', fontWeight: 600 }}>
                    🤖 ML Risk: {analysis.mlRiskLevel} ({analysis.mlConfidence}% confidence)
                  </span>
                  <span style={{ background: 'rgba(255,107,53,0.12)', border: '1px solid #ff6b3540', borderRadius: '20px', padding: '3px 12px', fontSize: '10px', color: '#ff6b35', fontWeight: 600 }}>
                    📅 {analysis.lstPeriod}
                  </span>
                </motion.div>
              )}
            </motion.div>
          </div>

          {/* ── DASHBOARD PANELS (only when analysis loaded) ── */}
          <AnimatePresence>
            {analysis && !loading && (activeSection === 'dashboard' || activeSection === 'predictions' || activeSection === 'drivers') && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
                <DashboardPanel
                  analysis={analysis}
                  hotspots={hotspots}
                  interventions={interventions}
                  selectedCity={selectedCity}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── HEAT MAP (shows on heatmap section OR always when data loaded) ── */}
          <AnimatePresence>
            {analysis && !loading && (activeSection === 'dashboard' || activeSection === 'heatmap' || activeSection === 'hotspots') && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                style={{ background: '#0d1628', border: '1px solid #1e2d4a', borderRadius: '12px', padding: '14px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px', flexWrap: 'wrap', gap: '6px' }}>
                  <h3 style={{ color: '#f0f4ff', fontWeight: 700, fontSize: '12px' }}>🗺️ Heat Stress Map — {analysis.city}</h3>
                  <div style={{ display: 'flex', gap: '10px', fontSize: '10px' }}>
                    {['low', 'medium', 'high', 'extreme'].map(r => (
                      <span key={r} style={{ color: getRiskColor(r), display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <span style={{ width: 7, height: 7, borderRadius: '50%', background: getRiskColor(r), display: 'inline-block' }} />{r}
                      </span>
                    ))}
                  </div>
                </div>
                <HeatMap city={selectedCity} hotspots={hotspots} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* ── TAB BAR (below map) ── */}
          {analysis && !loading && (
            <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
              {[
                { key: 'hotspots', label: '🔥 Heat Hotspots' },
                { key: 'interventions', label: '❄️ Cooling Interventions' },
                { key: 'predict', label: '🤖 Heat Risk Predictor' },
                { key: 'simulate', label: '🧪 Scenario Simulator' },
                { key: 'compare', label: '🏙️ City Comparison' },
              ].map(tab => (
                <button key={tab.key}
                  onClick={() => { setActiveTab(tab.key as any); setActiveSection(tab.key === 'hotspots' ? 'hotspots' : tab.key === 'interventions' ? 'cooling' : tab.key === 'simulate' ? 'simulate' : 'predictions'); }}
                  style={{
                    padding: '7px 16px', borderRadius: '20px', border: 'none', cursor: 'pointer',
                    background: activeTab === tab.key ? 'linear-gradient(135deg, #00d4aa, #0099ff)' : 'rgba(255,255,255,0.05)',
                    color: activeTab === tab.key ? '#fff' : '#8892b0',
                    fontWeight: 600, fontSize: '11px',
                  }}>{tab.label}</button>
              ))}
            </div>
          )}

          {/* ── TAB CONTENT ── */}
          <AnimatePresence mode="wait">
            {analysis && !loading && activeTab === 'hotspots' && (
              <motion.div key="hotspots" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                style={{ background: '#0d1628', border: '1px solid #1e2d4a', borderRadius: '12px', overflow: 'hidden' }}>
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '12px' }}>
                    <thead>
                      <tr style={{ borderBottom: '1px solid #1e2d4a' }}>
                        {['District', 'LST (°C)', 'NDVI', 'NDBI', 'Humidity', 'Risk Level'].map(h => (
                          <th key={h} style={{ padding: '10px 14px', textAlign: 'left', color: '#8892b0', fontWeight: 600, fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.06em' }}>{h}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {hotspots.map((h: any, i: number) => (
                        <tr key={i} style={{ borderBottom: '1px solid #0d1628' }}>
                          <td style={{ padding: '9px 14px', color: '#f0f4ff' }}>{h.district}</td>
                          <td style={{ padding: '9px 14px', color: '#ff6b35', fontWeight: 700 }}>{h.lst}</td>
                          <td style={{ padding: '9px 14px', color: '#00d4aa' }}>{h.ndvi}</td>
                          <td style={{ padding: '9px 14px', color: '#ffd700' }}>{h.ndbi}</td>
                          <td style={{ padding: '9px 14px', color: '#0099ff' }}>{h.humidity}%</td>
                          <td style={{ padding: '9px 14px' }}>
                            <span style={{ padding: '3px 10px', borderRadius: '20px', fontSize: '10px', fontWeight: 700, background: `${getRiskColor(h.heatRisk)}20`, color: getRiskColor(h.heatRisk), border: `1px solid ${getRiskColor(h.heatRisk)}40` }}>
                              {h.heatRisk?.toUpperCase()}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {analysis && !loading && activeTab === 'interventions' && (
              <motion.div key="interventions" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '10px' }}>
                {interventions.map((inv: any, i: number) => (
                  <motion.div key={i} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    style={{ background: '#0d1628', border: '1px solid #1e2d4a', borderRadius: '12px', padding: '14px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px' }}>
                      <div style={{ fontSize: '22px' }}>{interventionIcons[inv.type]}</div>
                      <span style={{ padding: '2px 8px', borderRadius: '20px', fontSize: '9px', fontWeight: 700, background: getRiskColor(inv.priority) + '20', color: getRiskColor(inv.priority), border: `1px solid ${getRiskColor(inv.priority)}40` }}>
                        {inv.priority?.toUpperCase()}
                      </span>
                    </div>
                    <div style={{ fontSize: '12px', fontWeight: 700, color: '#f0f4ff', marginBottom: '4px', textTransform: 'capitalize' }}>
                      {inv.type?.replace(/_/g, ' ')}
                    </div>
                    <div style={{ fontSize: '10px', color: '#8892b0', marginBottom: '10px' }}>📍 {inv.area}</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px' }}>
                      <span style={{ color: '#00d4aa' }}>❄️ -{inv.tempReduction}°C</span>
                      <span style={{ color: '#ffd700' }}>Impact: {(inv.impactScore * 100).toFixed(0)}%</span>
                    </div>
                    <div style={{ marginTop: '6px', fontSize: '10px', color: '#8892b0' }}>💰 Est. ₹{(inv.estimatedCost / 100000).toFixed(1)}L</div>
                  </motion.div>
                ))}
              </motion.div>
            )}

            {analysis && !loading && activeTab === 'predict' && (
              <motion.div key="predict" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                style={{ background: '#0d1628', border: '1px solid #1e2d4a', borderRadius: '12px', padding: '18px' }}>
                <h3 style={{ color: '#f0f4ff', fontWeight: 700, marginBottom: '14px', fontSize: '12px' }}>🤖 Custom Heat Risk Predictor</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '12px', marginBottom: '14px' }}>
                  {[
                    { key: 'lst', label: 'Land Surface Temp (°C)', min: 20, max: 60, step: 0.1 },
                    { key: 'ndvi', label: 'NDVI (Vegetation)', min: -0.2, max: 0.9, step: 0.01 },
                    { key: 'ndbi', label: 'NDBI (Built-up)', min: 0.1, max: 0.9, step: 0.01 },
                    { key: 'humidity', label: 'Humidity (%)', min: 10, max: 100, step: 1 },
                    { key: 'buildingDensity', label: 'Building Density (%)', min: 0, max: 100, step: 1 },
                  ].map(field => (
                    <div key={field.key}>
                      <label style={{ fontSize: '10px', color: '#8892b0', display: 'block', marginBottom: '4px' }}>{field.label}</label>
                      <input type="range" min={field.min} max={field.max} step={field.step}
                        value={(predictInput as any)[field.key]}
                        onChange={e => setPredictInput(prev => ({ ...prev, [field.key]: parseFloat(e.target.value) }))}
                        style={{ width: '100%', accentColor: '#00d4aa' }} />
                      <div style={{ fontSize: '12px', color: '#00d4aa', fontWeight: 700, textAlign: 'center' }}>
                        {(predictInput as any)[field.key]}
                      </div>
                    </div>
                  ))}
                </div>
                <button onClick={handlePredict}
                  style={{ padding: '8px 20px', borderRadius: '20px', border: 'none', background: 'linear-gradient(135deg, #00d4aa, #0099ff)', color: '#fff', fontWeight: 700, cursor: 'pointer', fontSize: '12px' }}>
                  🤖 Predict Heat Risk
                </button>
                {predictResult && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                    style={{ marginTop: '14px', padding: '14px', background: '#0a0f1e', borderRadius: '10px', border: '1px solid #1e2d4a' }}>
                    <div style={{ fontSize: '18px', fontWeight: 800, color: getRiskColor(predictResult.riskLevel), marginBottom: '8px' }}>
                      {predictResult.riskLevel} Risk — {predictResult.confidence}% confidence
                    </div>
                    <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap', marginBottom: '8px' }}>
                      {Object.entries(predictResult.probabilities || {}).map(([level, prob]: any) => (
                        <span key={level} style={{ fontSize: '10px', padding: '3px 8px', borderRadius: '4px', background: `${getRiskColor(level)}15`, color: getRiskColor(level) }}>
                          {level}: {prob}%
                        </span>
                      ))}
                    </div>
                    <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                      {predictResult.recommendations?.map((r: string, i: number) => (
                        <span key={i} style={{ fontSize: '10px', padding: '3px 10px', borderRadius: '6px', background: 'rgba(0,212,170,0.1)', color: '#00d4aa', border: '1px solid #00d4aa30' }}>
                          ✓ {r}
                        </span>
                      ))}
                    </div>
                  </motion.div>
                )}
              </motion.div>
            )}

            {analysis && !loading && activeTab === 'simulate' && (
              <motion.div key="simulate" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <ScenarioSimulator city={selectedCity} baseLST={analysis.avgLST} originalRisk={analysis.mlRiskLevel} population={analysis.affectedPopulation} />
              </motion.div>
            )}

            {activeTab === 'compare' && (
              <motion.div key="compare" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <CityComparison />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Footer */}
          <div style={{ textAlign: 'center', padding: '12px 0 4px', fontSize: '10px', color: '#1e2d4a' }}>
            Urban Heat Intelligence Platform | Powered by AI/ML & ISRO Data 🚀 &nbsp;|&nbsp; Developed for ISRO Hackathon 2026
          </div>
        </div>
      </div>
    </div>
  );
}